#!/bin/bash
cp -rf *.hrc ~/.config/far2l/plugins/colorer
cp -rf colors.ini ~/.config/far2l/settings/
sed -i 's/ChangeBgEditor\=0/ChangeBgEditor\=1/g' ~/.config/far2l/plugins/colorer/config.ini
sed -i 's/TrueMod\=0/TrueMod\=1/g' ~/.config/far2l/plugins/colorer/config.ini
sed -i 's/HrdNameTm\=default/HrdNameTm\=black/g' ~/.config/far2l/plugins/colorer/config.ini
echo UserHrcPath=\~/.config/far2l/plugins/colorer/user.hrc >> ~/.config/far2l/plugins/colorer/config.ini
