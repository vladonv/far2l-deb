#!/bin/bash
rm -rf ~/.config/far2l/settings/colors.ini
rm -rf ~/.config/far2l/plugins/colorer/*.hrc
sed -i 's/UserHrcPath\=\~\/.config\/far2l\/plugins\/colorer\/user.hrc//g' ~/.config/far2l/plugins/colorer/config.ini
sed -i 's/HrdNameTm\=black/HrdNameTm\=default/g' ~/.config/far2l/plugins/colorer/config.ini
