#!/bin/bash
rm -rf ~/.config/far2l/palette.ini
rm -rf ~/.config/far2l/settings/colors.ini
rm -rf ~/.config/far2l/plugins/colorer/base
sed -i 's/Catalog\=\~\/\.config\/far2l\/plugins\/colorer\/base\/catalog\.xml/Catalog\=/g' ~/.config/far2l/plugins/colorer/config.ini
